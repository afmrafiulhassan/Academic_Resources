import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Form2 extends JFrame implements ActionListener {
	private JLabel label;
	private JPanel panel;
	private Font myFont;
	private JButton backBtn;
	private Form1 f1;
	private Account a;
	
	private JTextArea jta;
	
	public Form2(Form1 f1, Account a){
			super("Form2");
			
			this.f1 = f1;
			this.a = a;
			
			this.setSize(400,500);
			this.setDefaultCloseOperation(EXIT_ON_CLOSE);
			this.setLayout(null);
			
			myFont = new Font("Cambria", Font.PLAIN, 25);
			
			panel = new JPanel();
			panel.setBounds(0,0,400,500);
			panel.setLayout(null);
			panel.setBackground(new Color(240,240,240));
			
			label = new JLabel();
			label.setText(a.getAccountNumber()+"");
			label.setFont(myFont);
			label.setBounds(10,0, 300, 50);
			panel.add(label);
			
			
			backBtn = new JButton("< Back");
			backBtn.setBounds(10,50,200,50);
			backBtn.addActionListener(this);
			panel.add(backBtn);
		
				
			this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae){
		String command = ae.getActionCommand();	
		if(ae.getSource() == backBtn){
			f1.setVisible(true);
			this.setVisible(false);
			this.dispose();
		}
	}

	
}