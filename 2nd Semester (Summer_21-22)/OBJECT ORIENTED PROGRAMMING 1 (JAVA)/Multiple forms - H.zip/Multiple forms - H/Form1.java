import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Form1 extends JFrame implements ActionListener {
	private JLabel label;
	private JPanel panel;
	private Font myFont;
	private JButton profileBtn;
	private Account a;
	private JTable jt;
	
	public Form1(Account a){
			super("HOME PAGE");
			this.a = a;
			
			this.setSize(400,500);
			this.setDefaultCloseOperation(EXIT_ON_CLOSE);
			this.setLayout(null);
		
			myFont = new Font("Cambria", Font.PLAIN, 25);
			
			panel = new JPanel();
			panel.setBounds(0,0,400,500);
			panel.setLayout(null);
			panel.setBackground(new Color(240,240,240));
			
			label = new JLabel();
			label.setText(a.getAccountHolderName());
			label.setFont(myFont);
			label.setBounds(10,0, 300, 50);
			panel.add(label);
			
			profileBtn = new JButton("Profile");
			profileBtn.setBounds(10,50,200,50);
			profileBtn.addActionListener(this);
			panel.add(profileBtn);
			
			JScrollPane jsp = new JScrollPane();
			jsp.setBounds(0,150,300,100);
			panel.add(jsp);
			
			String col[] = {"Name","ACCNO","BALANCE"};
			Object data[][]={ {a.getAccountHolderName(),a.getAccountNumber(),a.getBalance()}, 
							  {"RAHIM",2222,2000},
							  {"ABDUL",3333,3000},
							  {"BARI",4333,4000},
							  {"KARIM",1111,1000}, 
							  {"RAHIM",2222,2000},
							  {"ABDUL",3333,3000}};
			
			jt = new JTable(data,col);
			jt.setBounds(0,200,300,200);
			jsp.setViewportView(jt);
			//panel.add(jt);
			
			
			this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae){
		String command = ae.getActionCommand();	
		
		if( ae.getSource() == profileBtn ){
			Form2 f2 = new Form2(this,a);

			f2.setVisible(true);
			this.setVisible(false);
		}
	}
	
}