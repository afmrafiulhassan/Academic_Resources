class Start{
	public static void main(String []args){
		
		Account a = new Account(1111,"MAHMUD",2000);
		
		Form1 f1 = new Form1(a);
		f1.setVisible(true);
		
	}
}