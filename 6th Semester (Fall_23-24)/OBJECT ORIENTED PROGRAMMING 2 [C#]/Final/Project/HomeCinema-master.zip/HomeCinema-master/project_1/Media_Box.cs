﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1
{
    public partial class Media_Box : UserControl
    {
        private string _title;
        private string _poster_path;
        private string _video_url;
        private string _director_name;
        private string _main_actor_name;
        private string _rating;
        private string _language; 
        private Timer timer;
        private Form videoDetailsForm;
        public Media_Box()
        {
            InitializeComponent();
            InitializeTimer();
            InitializeVideoDetailsForm();
            
        }
        #region
        public string DirectorName
        {
            get { return _director_name; }
            set { _director_name = value; }
        }

        // Property for Main Actor Name
        public string MainActorName
        {
            get { return _main_actor_name; }
            set { _main_actor_name = value; }
        }

        // Property for Rating
        public string Rating
        {
            get { return _rating; }
            set { _rating = value; }
        }

        // Property for Language
        public string Language
        {
            get { return _language; }
            set { _language = value; }
        }
        public string title
        {
            get { return _title; }
            set { _title = value; Title_lable.Text = value; }
        }
        public string video_utl
        {
            get { return (string)_video_url; }
            set { _video_url = value; }
        }
        public string poster_path
        {
            set { _poster_path = value; }//  Image image = Image.FromFile(value); poster.Image = image;}
            get { return _poster_path; }

        }
        private void TimerTickHandler(object sender, EventArgs e)
        {
            timer.Stop();
            this.label1.Text = $"Directed By : {DirectorName}";
            this.label1.Visible = true;
            this.label2.Text = $"Rating : {Rating}";
            this.label2.Visible = true;
            this.label4.Text =$"Main Character : {MainActorName}";
            this.label4.Visible = true;
            this.label3.Text = $"Language : {Language}";
            this.label3 .Visible = true;
            //ShowVideoDetails();
        }
        public void Mouse_leave(object sender, EventArgs e)
        {

            this.BackColor = Color.FromArgb(132, 158, 145);
            timer.Stop();
            this.Title_lable.Visible = false;
            this.label2.Visible = false;
            this.label1.Visible = false;
            this.label3.Visible = false;
            this.label4.Visible = false;
           // this.panel1.Visible = false;




        }
        public void Mouse_click(object sender, MouseEventArgs e)
        {
            //this.video_utl = @"C:\Users\pc\Desktop\server\Media\Interstellar.mp4";
            //MessageBox.Show("media box clicked");
            if (Form2.is_play == false)
            {
                Form2 play = new Form2(this.video_utl);
                play.Show();
            }
           

        }
        #endregion

        private void Mouse_endter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(77, 96, 75);
          //  MessageBox.Show("Swajan");
            timer.Start();
            this.Title_lable.Visible = true;
           // this.label2.Visible = true; 
            //this.panel1.BackgroundImage = Image.FromFile(this.poster_path);
            //this.panel1.Visible = true;
         




        }
        private void MouseMoveHandler(object sender, MouseEventArgs e)
        {
            if (videoDetailsForm != null)
            {
                videoDetailsForm.Close();
            }
        }
        private void InitializeTimer()
        {
            timer = new Timer();
            timer.Interval = 2000; // 10 seconds
            timer.Tick += TimerTickHandler;

        }
        private void InitializeVideoDetailsForm()
        {
            videoDetailsForm = new Form();
            videoDetailsForm.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            videoDetailsForm.StartPosition = FormStartPosition.Manual;
            videoDetailsForm.ShowInTaskbar = false;
            videoDetailsForm.Size = new Size(200, 100);
            videoDetailsForm.TopMost = true;
            videoDetailsForm.Opacity = 0.95;
            videoDetailsForm.Location = new Point(20, 20);
            videoDetailsForm.MouseMove += MouseMoveHandler;
            videoDetailsForm.MouseLeave += VideoDetailsFormMouseLeave;
            
        }
        private void ShowVideoDetails()
        {
            // Display video details in a MessageBox-like form
            videoDetailsForm.Location = this.PointToScreen(new Point(0, 0));
            Label label = new Label();
            label.Text = $"Title: {title}";
            label.Dock = DockStyle.Fill;
            videoDetailsForm.Controls.Add(label);
            videoDetailsForm.ShowDialog();
        }
        private void VideoDetailsFormMouseLeave(object sender, EventArgs e)
        {
            // Close the videoDetailsForm when the mouse leaves the form
            if (videoDetailsForm != null)
            {
                videoDetailsForm.Close();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
