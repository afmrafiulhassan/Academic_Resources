﻿using System.Drawing;

namespace project_1
{
    partial class Home_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home_Page));
            this.si_fi_flowLayoutPane = new System.Windows.Forms.FlowLayoutPanel();
            this.action_flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.anime_flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.comedy_flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.search_btn = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.upload_picture = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.search_res_flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.recently_added_flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.media_Box33 = new project_1.Media_Box();
            this.media_Box34 = new project_1.Media_Box();
            this.media_Box35 = new project_1.Media_Box();
            this.media_Box36 = new project_1.Media_Box();
            this.media_Box37 = new project_1.Media_Box();
            this.media_Box38 = new project_1.Media_Box();
            this.media_Box39 = new project_1.Media_Box();
            this.media_Box40 = new project_1.Media_Box();
            this.media_Box25 = new project_1.Media_Box();
            this.media_Box26 = new project_1.Media_Box();
            this.media_Box27 = new project_1.Media_Box();
            this.media_Box28 = new project_1.Media_Box();
            this.media_Box29 = new project_1.Media_Box();
            this.media_Box30 = new project_1.Media_Box();
            this.media_Box31 = new project_1.Media_Box();
            this.media_Box32 = new project_1.Media_Box();
            this.media_Box17 = new project_1.Media_Box();
            this.media_Box18 = new project_1.Media_Box();
            this.media_Box19 = new project_1.Media_Box();
            this.media_Box20 = new project_1.Media_Box();
            this.media_Box21 = new project_1.Media_Box();
            this.media_Box22 = new project_1.Media_Box();
            this.media_Box23 = new project_1.Media_Box();
            this.media_Box24 = new project_1.Media_Box();
            this.media_Box1 = new project_1.Media_Box();
            this.media_Box2 = new project_1.Media_Box();
            this.media_Box3 = new project_1.Media_Box();
            this.media_Box4 = new project_1.Media_Box();
            this.media_Box5 = new project_1.Media_Box();
            this.media_Box6 = new project_1.Media_Box();
            this.media_Box7 = new project_1.Media_Box();
            this.media_Box8 = new project_1.Media_Box();
            this.media_Box9 = new project_1.Media_Box();
            this.media_Box10 = new project_1.Media_Box();
            this.media_Box11 = new project_1.Media_Box();
            this.media_Box12 = new project_1.Media_Box();
            this.media_Box13 = new project_1.Media_Box();
            this.media_Box14 = new project_1.Media_Box();
            this.media_Box15 = new project_1.Media_Box();
            this.media_Box16 = new project_1.Media_Box();
            this.si_fi_flowLayoutPane.SuspendLayout();
            this.action_flowLayoutPanel.SuspendLayout();
            this.anime_flowLayoutPanel.SuspendLayout();
            this.comedy_flowLayoutPanel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.upload_picture)).BeginInit();
            this.recently_added_flowLayoutPanel.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // si_fi_flowLayoutPane
            // 
            this.si_fi_flowLayoutPane.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.si_fi_flowLayoutPane.AutoScroll = true;
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box1);
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box2);
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box3);
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box4);
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box5);
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box6);
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box7);
            this.si_fi_flowLayoutPane.Controls.Add(this.media_Box8);
            this.si_fi_flowLayoutPane.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.si_fi_flowLayoutPane.Location = new System.Drawing.Point(44, 595);
            this.si_fi_flowLayoutPane.Name = "si_fi_flowLayoutPane";
            this.si_fi_flowLayoutPane.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.si_fi_flowLayoutPane.Size = new System.Drawing.Size(1118, 216);
            this.si_fi_flowLayoutPane.TabIndex = 0;
            // 
            // action_flowLayoutPanel
            // 
            this.action_flowLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.action_flowLayoutPanel.AutoScroll = true;
            this.action_flowLayoutPanel.Controls.Add(this.media_Box9);
            this.action_flowLayoutPanel.Controls.Add(this.media_Box10);
            this.action_flowLayoutPanel.Controls.Add(this.media_Box11);
            this.action_flowLayoutPanel.Controls.Add(this.media_Box12);
            this.action_flowLayoutPanel.Controls.Add(this.media_Box13);
            this.action_flowLayoutPanel.Controls.Add(this.media_Box14);
            this.action_flowLayoutPanel.Controls.Add(this.media_Box15);
            this.action_flowLayoutPanel.Controls.Add(this.media_Box16);
            this.action_flowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.action_flowLayoutPanel.Location = new System.Drawing.Point(44, 834);
            this.action_flowLayoutPanel.Name = "action_flowLayoutPanel";
            this.action_flowLayoutPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.action_flowLayoutPanel.Size = new System.Drawing.Size(1118, 216);
            this.action_flowLayoutPanel.TabIndex = 8;
            // 
            // anime_flowLayoutPanel
            // 
            this.anime_flowLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.anime_flowLayoutPanel.AutoScroll = true;
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box17);
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box18);
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box19);
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box20);
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box21);
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box22);
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box23);
            this.anime_flowLayoutPanel.Controls.Add(this.media_Box24);
            this.anime_flowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.anime_flowLayoutPanel.Location = new System.Drawing.Point(44, 1062);
            this.anime_flowLayoutPanel.Name = "anime_flowLayoutPanel";
            this.anime_flowLayoutPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.anime_flowLayoutPanel.Size = new System.Drawing.Size(1118, 216);
            this.anime_flowLayoutPanel.TabIndex = 9;
            // 
            // comedy_flowLayoutPanel4
            // 
            this.comedy_flowLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comedy_flowLayoutPanel4.AutoScroll = true;
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box25);
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box26);
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box27);
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box28);
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box29);
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box30);
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box31);
            this.comedy_flowLayoutPanel4.Controls.Add(this.media_Box32);
            this.comedy_flowLayoutPanel4.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.comedy_flowLayoutPanel4.Location = new System.Drawing.Point(43, 1303);
            this.comedy_flowLayoutPanel4.Name = "comedy_flowLayoutPanel4";
            this.comedy_flowLayoutPanel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comedy_flowLayoutPanel4.Size = new System.Drawing.Size(1119, 216);
            this.comedy_flowLayoutPanel4.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(43, 559);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1119, 33);
            this.panel1.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label1.Location = new System.Drawing.Point(12, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "SI-FI";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(44, 795);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1118, 33);
            this.panel2.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label2.Location = new System.Drawing.Point(9, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Action";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(44, 1026);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1118, 33);
            this.panel3.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label3.Location = new System.Drawing.Point(9, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Horror";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(43, 1264);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1119, 33);
            this.panel4.TabIndex = 14;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label4.Location = new System.Drawing.Point(9, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "Comedies";
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // search_btn
            // 
            this.search_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.search_btn.BackColor = System.Drawing.Color.White;
            this.search_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("search_btn.BackgroundImage")));
            this.search_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.search_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.search_btn.Location = new System.Drawing.Point(913, 26);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(30, 25);
            this.search_btn.TabIndex = 16;
            this.search_btn.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel6.Location = new System.Drawing.Point(4, 97);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(33, 5848);
            this.panel6.TabIndex = 18;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(949, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 29);
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(40, -74);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(272, 215);
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Location = new System.Drawing.Point(1161, 161);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(33, 6138);
            this.panel5.TabIndex = 19;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.Controls.Add(this.pictureBox2);
            this.panel7.Location = new System.Drawing.Point(4, 12);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(483, 71);
            this.panel7.TabIndex = 21;
            // 
            // upload_picture
            // 
            this.upload_picture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.upload_picture.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("upload_picture.BackgroundImage")));
            this.upload_picture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.upload_picture.Location = new System.Drawing.Point(991, 19);
            this.upload_picture.Name = "upload_picture";
            this.upload_picture.Size = new System.Drawing.Size(35, 35);
            this.upload_picture.TabIndex = 21;
            this.upload_picture.TabStop = false;
            this.upload_picture.Click += new System.EventHandler(this.upload_picture_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(744, 26);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(163, 25);
            this.textBox1.TabIndex = 22;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // search_res_flowLayoutPanel
            // 
            this.search_res_flowLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.search_res_flowLayoutPanel.AutoSize = true;
            this.search_res_flowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.search_res_flowLayoutPanel.Location = new System.Drawing.Point(744, 60);
            this.search_res_flowLayoutPanel.Name = "search_res_flowLayoutPanel";
            this.search_res_flowLayoutPanel.Size = new System.Drawing.Size(341, 0);
            this.search_res_flowLayoutPanel.TabIndex = 23;
            // 
            // recently_added_flowLayoutPanel
            // 
            this.recently_added_flowLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.recently_added_flowLayoutPanel.AutoScroll = true;
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box33);
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box34);
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box35);
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box36);
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box37);
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box38);
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box39);
            this.recently_added_flowLayoutPanel.Controls.Add(this.media_Box40);
            this.recently_added_flowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.recently_added_flowLayoutPanel.Location = new System.Drawing.Point(43, 359);
            this.recently_added_flowLayoutPanel.Name = "recently_added_flowLayoutPanel";
            this.recently_added_flowLayoutPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.recently_added_flowLayoutPanel.Size = new System.Drawing.Size(1119, 216);
            this.recently_added_flowLayoutPanel.TabIndex = 10;
            // 
            // panel8
            // 
            this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.panel8.Controls.Add(this.label5);
            this.panel8.Location = new System.Drawing.Point(43, 320);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1119, 33);
            this.panel8.TabIndex = 14;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label5.Location = new System.Drawing.Point(9, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 25);
            this.label5.TabIndex = 1;
            this.label5.Text = "Recently Added";
            // 
            // panel9
            // 
            this.panel9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel9.Location = new System.Drawing.Point(36, 89);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1126, 228);
            this.panel9.TabIndex = 24;
            // 
            // media_Box33
            // 
            this.media_Box33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box33.DirectorName = null;
            this.media_Box33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box33.Language = null;
            this.media_Box33.Location = new System.Drawing.Point(3, 4);
            this.media_Box33.MainActorName = null;
            this.media_Box33.Name = "media_Box33";
            this.media_Box33.poster_path = null;
            this.media_Box33.Rating = null;
            this.media_Box33.Size = new System.Drawing.Size(270, 192);
            this.media_Box33.TabIndex = 0;
            this.media_Box33.title = null;
            this.media_Box33.video_utl = null;
            // 
            // media_Box34
            // 
            this.media_Box34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box34.DirectorName = null;
            this.media_Box34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box34.Language = null;
            this.media_Box34.Location = new System.Drawing.Point(279, 4);
            this.media_Box34.MainActorName = null;
            this.media_Box34.Name = "media_Box34";
            this.media_Box34.poster_path = null;
            this.media_Box34.Rating = null;
            this.media_Box34.Size = new System.Drawing.Size(270, 192);
            this.media_Box34.TabIndex = 1;
            this.media_Box34.title = null;
            this.media_Box34.video_utl = null;
            // 
            // media_Box35
            // 
            this.media_Box35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box35.DirectorName = null;
            this.media_Box35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box35.Language = null;
            this.media_Box35.Location = new System.Drawing.Point(555, 4);
            this.media_Box35.MainActorName = null;
            this.media_Box35.Name = "media_Box35";
            this.media_Box35.poster_path = null;
            this.media_Box35.Rating = null;
            this.media_Box35.Size = new System.Drawing.Size(270, 192);
            this.media_Box35.TabIndex = 2;
            this.media_Box35.title = null;
            this.media_Box35.video_utl = null;
            // 
            // media_Box36
            // 
            this.media_Box36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box36.DirectorName = null;
            this.media_Box36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box36.Language = null;
            this.media_Box36.Location = new System.Drawing.Point(831, 4);
            this.media_Box36.MainActorName = null;
            this.media_Box36.Name = "media_Box36";
            this.media_Box36.poster_path = null;
            this.media_Box36.Rating = null;
            this.media_Box36.Size = new System.Drawing.Size(270, 192);
            this.media_Box36.TabIndex = 3;
            this.media_Box36.title = null;
            this.media_Box36.video_utl = null;
            // 
            // media_Box37
            // 
            this.media_Box37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box37.DirectorName = null;
            this.media_Box37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box37.Language = null;
            this.media_Box37.Location = new System.Drawing.Point(1107, 4);
            this.media_Box37.MainActorName = null;
            this.media_Box37.Name = "media_Box37";
            this.media_Box37.poster_path = null;
            this.media_Box37.Rating = null;
            this.media_Box37.Size = new System.Drawing.Size(270, 192);
            this.media_Box37.TabIndex = 4;
            this.media_Box37.title = null;
            this.media_Box37.video_utl = null;
            // 
            // media_Box38
            // 
            this.media_Box38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box38.DirectorName = null;
            this.media_Box38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box38.Language = null;
            this.media_Box38.Location = new System.Drawing.Point(1383, 4);
            this.media_Box38.MainActorName = null;
            this.media_Box38.Name = "media_Box38";
            this.media_Box38.poster_path = null;
            this.media_Box38.Rating = null;
            this.media_Box38.Size = new System.Drawing.Size(270, 192);
            this.media_Box38.TabIndex = 5;
            this.media_Box38.title = null;
            this.media_Box38.video_utl = null;
            // 
            // media_Box39
            // 
            this.media_Box39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box39.DirectorName = null;
            this.media_Box39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box39.Language = null;
            this.media_Box39.Location = new System.Drawing.Point(1659, 4);
            this.media_Box39.MainActorName = null;
            this.media_Box39.Name = "media_Box39";
            this.media_Box39.poster_path = null;
            this.media_Box39.Rating = null;
            this.media_Box39.Size = new System.Drawing.Size(270, 192);
            this.media_Box39.TabIndex = 6;
            this.media_Box39.title = null;
            this.media_Box39.video_utl = null;
            // 
            // media_Box40
            // 
            this.media_Box40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box40.DirectorName = null;
            this.media_Box40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box40.Language = null;
            this.media_Box40.Location = new System.Drawing.Point(1935, 4);
            this.media_Box40.MainActorName = null;
            this.media_Box40.Name = "media_Box40";
            this.media_Box40.poster_path = null;
            this.media_Box40.Rating = null;
            this.media_Box40.Size = new System.Drawing.Size(270, 192);
            this.media_Box40.TabIndex = 7;
            this.media_Box40.title = null;
            this.media_Box40.video_utl = null;
            // 
            // media_Box25
            // 
            this.media_Box25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box25.DirectorName = null;
            this.media_Box25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box25.Language = null;
            this.media_Box25.Location = new System.Drawing.Point(3, 4);
            this.media_Box25.MainActorName = null;
            this.media_Box25.Name = "media_Box25";
            this.media_Box25.poster_path = null;
            this.media_Box25.Rating = null;
            this.media_Box25.Size = new System.Drawing.Size(270, 192);
            this.media_Box25.TabIndex = 0;
            this.media_Box25.title = null;
            this.media_Box25.video_utl = null;
            // 
            // media_Box26
            // 
            this.media_Box26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box26.DirectorName = null;
            this.media_Box26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box26.Language = null;
            this.media_Box26.Location = new System.Drawing.Point(279, 4);
            this.media_Box26.MainActorName = null;
            this.media_Box26.Name = "media_Box26";
            this.media_Box26.poster_path = null;
            this.media_Box26.Rating = null;
            this.media_Box26.Size = new System.Drawing.Size(270, 192);
            this.media_Box26.TabIndex = 1;
            this.media_Box26.title = null;
            this.media_Box26.video_utl = null;
            // 
            // media_Box27
            // 
            this.media_Box27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box27.DirectorName = null;
            this.media_Box27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box27.Language = null;
            this.media_Box27.Location = new System.Drawing.Point(555, 4);
            this.media_Box27.MainActorName = null;
            this.media_Box27.Name = "media_Box27";
            this.media_Box27.poster_path = null;
            this.media_Box27.Rating = null;
            this.media_Box27.Size = new System.Drawing.Size(270, 192);
            this.media_Box27.TabIndex = 2;
            this.media_Box27.title = null;
            this.media_Box27.video_utl = null;
            // 
            // media_Box28
            // 
            this.media_Box28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box28.DirectorName = null;
            this.media_Box28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box28.Language = null;
            this.media_Box28.Location = new System.Drawing.Point(831, 4);
            this.media_Box28.MainActorName = null;
            this.media_Box28.Name = "media_Box28";
            this.media_Box28.poster_path = null;
            this.media_Box28.Rating = null;
            this.media_Box28.Size = new System.Drawing.Size(270, 192);
            this.media_Box28.TabIndex = 3;
            this.media_Box28.title = null;
            this.media_Box28.video_utl = null;
            // 
            // media_Box29
            // 
            this.media_Box29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box29.DirectorName = null;
            this.media_Box29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box29.Language = null;
            this.media_Box29.Location = new System.Drawing.Point(1107, 4);
            this.media_Box29.MainActorName = null;
            this.media_Box29.Name = "media_Box29";
            this.media_Box29.poster_path = null;
            this.media_Box29.Rating = null;
            this.media_Box29.Size = new System.Drawing.Size(270, 192);
            this.media_Box29.TabIndex = 4;
            this.media_Box29.title = null;
            this.media_Box29.video_utl = null;
            // 
            // media_Box30
            // 
            this.media_Box30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box30.DirectorName = null;
            this.media_Box30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box30.Language = null;
            this.media_Box30.Location = new System.Drawing.Point(1383, 4);
            this.media_Box30.MainActorName = null;
            this.media_Box30.Name = "media_Box30";
            this.media_Box30.poster_path = null;
            this.media_Box30.Rating = null;
            this.media_Box30.Size = new System.Drawing.Size(270, 192);
            this.media_Box30.TabIndex = 5;
            this.media_Box30.title = null;
            this.media_Box30.video_utl = null;
            // 
            // media_Box31
            // 
            this.media_Box31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box31.DirectorName = null;
            this.media_Box31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box31.Language = null;
            this.media_Box31.Location = new System.Drawing.Point(1659, 4);
            this.media_Box31.MainActorName = null;
            this.media_Box31.Name = "media_Box31";
            this.media_Box31.poster_path = null;
            this.media_Box31.Rating = null;
            this.media_Box31.Size = new System.Drawing.Size(270, 192);
            this.media_Box31.TabIndex = 6;
            this.media_Box31.title = null;
            this.media_Box31.video_utl = null;
            // 
            // media_Box32
            // 
            this.media_Box32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box32.DirectorName = null;
            this.media_Box32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box32.Language = null;
            this.media_Box32.Location = new System.Drawing.Point(1935, 4);
            this.media_Box32.MainActorName = null;
            this.media_Box32.Name = "media_Box32";
            this.media_Box32.poster_path = null;
            this.media_Box32.Rating = null;
            this.media_Box32.Size = new System.Drawing.Size(270, 192);
            this.media_Box32.TabIndex = 7;
            this.media_Box32.title = null;
            this.media_Box32.video_utl = null;
            // 
            // media_Box17
            // 
            this.media_Box17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box17.DirectorName = null;
            this.media_Box17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box17.Language = null;
            this.media_Box17.Location = new System.Drawing.Point(3, 4);
            this.media_Box17.MainActorName = null;
            this.media_Box17.Name = "media_Box17";
            this.media_Box17.poster_path = null;
            this.media_Box17.Rating = null;
            this.media_Box17.Size = new System.Drawing.Size(270, 192);
            this.media_Box17.TabIndex = 0;
            this.media_Box17.title = null;
            this.media_Box17.video_utl = null;
            // 
            // media_Box18
            // 
            this.media_Box18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box18.DirectorName = null;
            this.media_Box18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box18.Language = null;
            this.media_Box18.Location = new System.Drawing.Point(279, 4);
            this.media_Box18.MainActorName = null;
            this.media_Box18.Name = "media_Box18";
            this.media_Box18.poster_path = null;
            this.media_Box18.Rating = null;
            this.media_Box18.Size = new System.Drawing.Size(270, 192);
            this.media_Box18.TabIndex = 1;
            this.media_Box18.title = null;
            this.media_Box18.video_utl = null;
            // 
            // media_Box19
            // 
            this.media_Box19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box19.DirectorName = null;
            this.media_Box19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box19.Language = null;
            this.media_Box19.Location = new System.Drawing.Point(555, 4);
            this.media_Box19.MainActorName = null;
            this.media_Box19.Name = "media_Box19";
            this.media_Box19.poster_path = null;
            this.media_Box19.Rating = null;
            this.media_Box19.Size = new System.Drawing.Size(251, 192);
            this.media_Box19.TabIndex = 2;
            this.media_Box19.title = null;
            this.media_Box19.video_utl = null;
            // 
            // media_Box20
            // 
            this.media_Box20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box20.DirectorName = null;
            this.media_Box20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box20.Language = null;
            this.media_Box20.Location = new System.Drawing.Point(812, 4);
            this.media_Box20.MainActorName = null;
            this.media_Box20.Name = "media_Box20";
            this.media_Box20.poster_path = null;
            this.media_Box20.Rating = null;
            this.media_Box20.Size = new System.Drawing.Size(270, 192);
            this.media_Box20.TabIndex = 3;
            this.media_Box20.title = null;
            this.media_Box20.video_utl = null;
            // 
            // media_Box21
            // 
            this.media_Box21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box21.DirectorName = null;
            this.media_Box21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box21.Language = null;
            this.media_Box21.Location = new System.Drawing.Point(1088, 4);
            this.media_Box21.MainActorName = null;
            this.media_Box21.Name = "media_Box21";
            this.media_Box21.poster_path = null;
            this.media_Box21.Rating = null;
            this.media_Box21.Size = new System.Drawing.Size(270, 192);
            this.media_Box21.TabIndex = 4;
            this.media_Box21.title = null;
            this.media_Box21.video_utl = null;
            // 
            // media_Box22
            // 
            this.media_Box22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box22.DirectorName = null;
            this.media_Box22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box22.Language = null;
            this.media_Box22.Location = new System.Drawing.Point(1364, 4);
            this.media_Box22.MainActorName = null;
            this.media_Box22.Name = "media_Box22";
            this.media_Box22.poster_path = null;
            this.media_Box22.Rating = null;
            this.media_Box22.Size = new System.Drawing.Size(270, 192);
            this.media_Box22.TabIndex = 5;
            this.media_Box22.title = null;
            this.media_Box22.video_utl = null;
            // 
            // media_Box23
            // 
            this.media_Box23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box23.DirectorName = null;
            this.media_Box23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box23.Language = null;
            this.media_Box23.Location = new System.Drawing.Point(1640, 4);
            this.media_Box23.MainActorName = null;
            this.media_Box23.Name = "media_Box23";
            this.media_Box23.poster_path = null;
            this.media_Box23.Rating = null;
            this.media_Box23.Size = new System.Drawing.Size(270, 192);
            this.media_Box23.TabIndex = 6;
            this.media_Box23.title = null;
            this.media_Box23.video_utl = null;
            // 
            // media_Box24
            // 
            this.media_Box24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box24.DirectorName = null;
            this.media_Box24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box24.Language = null;
            this.media_Box24.Location = new System.Drawing.Point(1916, 4);
            this.media_Box24.MainActorName = null;
            this.media_Box24.Name = "media_Box24";
            this.media_Box24.poster_path = null;
            this.media_Box24.Rating = null;
            this.media_Box24.Size = new System.Drawing.Size(270, 192);
            this.media_Box24.TabIndex = 7;
            this.media_Box24.title = null;
            this.media_Box24.video_utl = null;
            // 
            // media_Box1
            // 
            this.media_Box1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box1.DirectorName = null;
            this.media_Box1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box1.Language = null;
            this.media_Box1.Location = new System.Drawing.Point(3, 4);
            this.media_Box1.MainActorName = null;
            this.media_Box1.Name = "media_Box1";
            this.media_Box1.poster_path = null;
            this.media_Box1.Rating = null;
            this.media_Box1.Size = new System.Drawing.Size(251, 192);
            this.media_Box1.TabIndex = 0;
            this.media_Box1.title = null;
            this.media_Box1.video_utl = null;
            // 
            // media_Box2
            // 
            this.media_Box2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box2.DirectorName = null;
            this.media_Box2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box2.Language = null;
            this.media_Box2.Location = new System.Drawing.Point(260, 4);
            this.media_Box2.MainActorName = null;
            this.media_Box2.Name = "media_Box2";
            this.media_Box2.poster_path = null;
            this.media_Box2.Rating = null;
            this.media_Box2.Size = new System.Drawing.Size(251, 192);
            this.media_Box2.TabIndex = 1;
            this.media_Box2.title = null;
            this.media_Box2.video_utl = null;
            // 
            // media_Box3
            // 
            this.media_Box3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box3.DirectorName = null;
            this.media_Box3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box3.Language = null;
            this.media_Box3.Location = new System.Drawing.Point(517, 4);
            this.media_Box3.MainActorName = null;
            this.media_Box3.Name = "media_Box3";
            this.media_Box3.poster_path = null;
            this.media_Box3.Rating = null;
            this.media_Box3.Size = new System.Drawing.Size(251, 192);
            this.media_Box3.TabIndex = 2;
            this.media_Box3.title = null;
            this.media_Box3.video_utl = null;
            // 
            // media_Box4
            // 
            this.media_Box4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box4.DirectorName = null;
            this.media_Box4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box4.Language = null;
            this.media_Box4.Location = new System.Drawing.Point(774, 4);
            this.media_Box4.MainActorName = null;
            this.media_Box4.Name = "media_Box4";
            this.media_Box4.poster_path = null;
            this.media_Box4.Rating = null;
            this.media_Box4.Size = new System.Drawing.Size(270, 192);
            this.media_Box4.TabIndex = 3;
            this.media_Box4.title = null;
            this.media_Box4.video_utl = null;
            // 
            // media_Box5
            // 
            this.media_Box5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box5.DirectorName = null;
            this.media_Box5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box5.Language = null;
            this.media_Box5.Location = new System.Drawing.Point(1050, 4);
            this.media_Box5.MainActorName = null;
            this.media_Box5.Name = "media_Box5";
            this.media_Box5.poster_path = null;
            this.media_Box5.Rating = null;
            this.media_Box5.Size = new System.Drawing.Size(270, 192);
            this.media_Box5.TabIndex = 4;
            this.media_Box5.title = null;
            this.media_Box5.video_utl = null;
            // 
            // media_Box6
            // 
            this.media_Box6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box6.DirectorName = null;
            this.media_Box6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box6.Language = null;
            this.media_Box6.Location = new System.Drawing.Point(1326, 4);
            this.media_Box6.MainActorName = null;
            this.media_Box6.Name = "media_Box6";
            this.media_Box6.poster_path = null;
            this.media_Box6.Rating = null;
            this.media_Box6.Size = new System.Drawing.Size(270, 192);
            this.media_Box6.TabIndex = 5;
            this.media_Box6.title = null;
            this.media_Box6.video_utl = null;
            // 
            // media_Box7
            // 
            this.media_Box7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box7.DirectorName = null;
            this.media_Box7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box7.Language = null;
            this.media_Box7.Location = new System.Drawing.Point(1602, 4);
            this.media_Box7.MainActorName = null;
            this.media_Box7.Name = "media_Box7";
            this.media_Box7.poster_path = null;
            this.media_Box7.Rating = null;
            this.media_Box7.Size = new System.Drawing.Size(270, 192);
            this.media_Box7.TabIndex = 6;
            this.media_Box7.title = null;
            this.media_Box7.video_utl = null;
            // 
            // media_Box8
            // 
            this.media_Box8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box8.DirectorName = null;
            this.media_Box8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box8.Language = null;
            this.media_Box8.Location = new System.Drawing.Point(1878, 4);
            this.media_Box8.MainActorName = null;
            this.media_Box8.Name = "media_Box8";
            this.media_Box8.poster_path = null;
            this.media_Box8.Rating = null;
            this.media_Box8.Size = new System.Drawing.Size(270, 192);
            this.media_Box8.TabIndex = 7;
            this.media_Box8.title = null;
            this.media_Box8.video_utl = null;
            // 
            // media_Box9
            // 
            this.media_Box9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box9.DirectorName = null;
            this.media_Box9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box9.Language = null;
            this.media_Box9.Location = new System.Drawing.Point(3, 4);
            this.media_Box9.MainActorName = null;
            this.media_Box9.Name = "media_Box9";
            this.media_Box9.poster_path = null;
            this.media_Box9.Rating = null;
            this.media_Box9.Size = new System.Drawing.Size(251, 192);
            this.media_Box9.TabIndex = 0;
            this.media_Box9.title = null;
            this.media_Box9.video_utl = null;
            // 
            // media_Box10
            // 
            this.media_Box10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box10.DirectorName = null;
            this.media_Box10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box10.Language = null;
            this.media_Box10.Location = new System.Drawing.Point(260, 4);
            this.media_Box10.MainActorName = null;
            this.media_Box10.Name = "media_Box10";
            this.media_Box10.poster_path = null;
            this.media_Box10.Rating = null;
            this.media_Box10.Size = new System.Drawing.Size(270, 192);
            this.media_Box10.TabIndex = 1;
            this.media_Box10.title = null;
            this.media_Box10.video_utl = null;
            // 
            // media_Box11
            // 
            this.media_Box11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box11.DirectorName = null;
            this.media_Box11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box11.Language = null;
            this.media_Box11.Location = new System.Drawing.Point(536, 4);
            this.media_Box11.MainActorName = null;
            this.media_Box11.Name = "media_Box11";
            this.media_Box11.poster_path = null;
            this.media_Box11.Rating = null;
            this.media_Box11.Size = new System.Drawing.Size(251, 192);
            this.media_Box11.TabIndex = 2;
            this.media_Box11.title = null;
            this.media_Box11.video_utl = null;
            // 
            // media_Box12
            // 
            this.media_Box12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box12.DirectorName = null;
            this.media_Box12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box12.Language = null;
            this.media_Box12.Location = new System.Drawing.Point(793, 4);
            this.media_Box12.MainActorName = null;
            this.media_Box12.Name = "media_Box12";
            this.media_Box12.poster_path = null;
            this.media_Box12.Rating = null;
            this.media_Box12.Size = new System.Drawing.Size(270, 192);
            this.media_Box12.TabIndex = 3;
            this.media_Box12.title = null;
            this.media_Box12.video_utl = null;
            // 
            // media_Box13
            // 
            this.media_Box13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box13.DirectorName = null;
            this.media_Box13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box13.Language = null;
            this.media_Box13.Location = new System.Drawing.Point(1069, 4);
            this.media_Box13.MainActorName = null;
            this.media_Box13.Name = "media_Box13";
            this.media_Box13.poster_path = null;
            this.media_Box13.Rating = null;
            this.media_Box13.Size = new System.Drawing.Size(270, 192);
            this.media_Box13.TabIndex = 4;
            this.media_Box13.title = null;
            this.media_Box13.video_utl = null;
            // 
            // media_Box14
            // 
            this.media_Box14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box14.DirectorName = null;
            this.media_Box14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box14.Language = null;
            this.media_Box14.Location = new System.Drawing.Point(1345, 4);
            this.media_Box14.MainActorName = null;
            this.media_Box14.Name = "media_Box14";
            this.media_Box14.poster_path = null;
            this.media_Box14.Rating = null;
            this.media_Box14.Size = new System.Drawing.Size(270, 192);
            this.media_Box14.TabIndex = 5;
            this.media_Box14.title = null;
            this.media_Box14.video_utl = null;
            // 
            // media_Box15
            // 
            this.media_Box15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box15.DirectorName = null;
            this.media_Box15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box15.Language = null;
            this.media_Box15.Location = new System.Drawing.Point(1621, 4);
            this.media_Box15.MainActorName = null;
            this.media_Box15.Name = "media_Box15";
            this.media_Box15.poster_path = null;
            this.media_Box15.Rating = null;
            this.media_Box15.Size = new System.Drawing.Size(270, 192);
            this.media_Box15.TabIndex = 6;
            this.media_Box15.title = null;
            this.media_Box15.video_utl = null;
            // 
            // media_Box16
            // 
            this.media_Box16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.media_Box16.DirectorName = null;
            this.media_Box16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(239)))), ((int)(((byte)(238)))));
            this.media_Box16.Language = null;
            this.media_Box16.Location = new System.Drawing.Point(1897, 4);
            this.media_Box16.MainActorName = null;
            this.media_Box16.Name = "media_Box16";
            this.media_Box16.poster_path = null;
            this.media_Box16.Rating = null;
            this.media_Box16.Size = new System.Drawing.Size(270, 192);
            this.media_Box16.TabIndex = 7;
            this.media_Box16.title = null;
            this.media_Box16.video_utl = null;
            // 
            // Home_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1314, 661);
            this.Controls.Add(this.search_res_flowLayoutPanel);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.recently_added_flowLayoutPanel);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.upload_picture);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.comedy_flowLayoutPanel4);
            this.Controls.Add(this.anime_flowLayoutPanel);
            this.Controls.Add(this.si_fi_flowLayoutPane);
            this.Controls.Add(this.action_flowLayoutPanel);
            this.Controls.Add(this.panel9);
            this.Name = "Home_Page";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home_Page";
            this.Load += new System.EventHandler(this.home_page_load);
            this.si_fi_flowLayoutPane.ResumeLayout(false);
            this.action_flowLayoutPanel.ResumeLayout(false);
            this.anime_flowLayoutPanel.ResumeLayout(false);
            this.comedy_flowLayoutPanel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.upload_picture)).EndInit();
            this.recently_added_flowLayoutPanel.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel si_fi_flowLayoutPane;
        private Media_Box media_Box1;
        private Media_Box media_Box2;
        private Media_Box media_Box3;
        private Media_Box media_Box4;
        private Media_Box media_Box5;
        private Media_Box media_Box6;
        private Media_Box media_Box7;
        private Media_Box media_Box8;
        private System.Windows.Forms.FlowLayoutPanel action_flowLayoutPanel;
        private Media_Box media_Box9;
        private Media_Box media_Box10;
        private Media_Box media_Box11;
        private Media_Box media_Box12;
        private Media_Box media_Box13;
        private Media_Box media_Box14;
        private Media_Box media_Box15;
        private Media_Box media_Box16;
        private System.Windows.Forms.FlowLayoutPanel anime_flowLayoutPanel;
        private Media_Box media_Box17;
        private Media_Box media_Box18;
        private Media_Box media_Box19;
        private Media_Box media_Box20;
        private Media_Box media_Box21;
        private Media_Box media_Box22;
        private Media_Box media_Box23;
        private Media_Box media_Box24;
        private System.Windows.Forms.FlowLayoutPanel comedy_flowLayoutPanel4;
        private Media_Box media_Box25;
        private Media_Box media_Box26;
        private Media_Box media_Box27;
        private Media_Box media_Box28;
        private Media_Box media_Box29;
        private Media_Box media_Box30;
        private Media_Box media_Box31;
        private Media_Box media_Box32;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Button search_btn;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox upload_picture;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FlowLayoutPanel search_res_flowLayoutPanel;
        private System.Windows.Forms.FlowLayoutPanel recently_added_flowLayoutPanel;
        private Media_Box media_Box33;
        private Media_Box media_Box34;
        private Media_Box media_Box35;
        private Media_Box media_Box36;
        private Media_Box media_Box37;
        private Media_Box media_Box38;
        private Media_Box media_Box39;
        private Media_Box media_Box40;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel9;
    }
}