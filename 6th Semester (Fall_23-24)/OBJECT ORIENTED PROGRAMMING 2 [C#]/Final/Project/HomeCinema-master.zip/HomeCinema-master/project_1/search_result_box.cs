﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1
{
    public partial class search_result_box : UserControl
    {
        public string Name { get; set; }
        public string title { get; set; }
        public string Director { get; set; }
        public string MainCharacter { get; set; }
        public float Rating { get; set; }
        public string VideoPath { get; set; }
        public string VideoPosterPath { get; set; }
        public string Language { get; set; }
        public string poster_path { get; set; }
        public search_result_box()
        {
            InitializeComponent();
        }
        public void Mouse_click(object sender, MouseEventArgs e)
        {
            //this.video_utl = @"C:\Users\pc\Desktop\server\Media\Interstellar.mp4";
            //MessageBox.Show("media box clicked");
            if (Form2.is_play == false)
            {
                Form2 play = new Form2(this.VideoPath);
                play.Show();
            }



        }
        private void search_result_box_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (Form2.is_play == false)
            {
                Form2 play = new Form2(this.VideoPath);
                play.Show();
            }
        }
        private void Mouse_endter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(77, 96, 75);
           
        }
        public void Mouse_leave(object sender, EventArgs e)
        {

            this.BackColor = Color.FromArgb(132, 158, 145);
 


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (Form2.is_play == false)
            {
                Form2 play = new Form2(this.VideoPath);
                play.Show();
            }
        }

        
    }
}
