﻿namespace project_1
{
    partial class search_result_box
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(search_result_box));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Title = new System.Windows.Forms.Label();
            this.director_name = new System.Windows.Forms.Label();
            this.language = new System.Windows.Forms.Label();
            this.rating = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(86, 88);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.pictureBox1.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.Title.Location = new System.Drawing.Point(92, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(36, 17);
            this.Title.TabIndex = 1;
            this.Title.Text = "Title";
            this.Title.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.Title.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // director_name
            // 
            this.director_name.AutoSize = true;
            this.director_name.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.director_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.director_name.Location = new System.Drawing.Point(175, 28);
            this.director_name.Name = "director_name";
            this.director_name.Size = new System.Drawing.Size(58, 17);
            this.director_name.TabIndex = 2;
            this.director_name.Text = "Director";
            this.director_name.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.director_name.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // language
            // 
            this.language.AutoSize = true;
            this.language.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.language.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.language.Location = new System.Drawing.Point(175, 45);
            this.language.Name = "language";
            this.language.Size = new System.Drawing.Size(68, 17);
            this.language.TabIndex = 3;
            this.language.Text = "Language";
            this.language.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.language.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // rating
            // 
            this.rating.AutoSize = true;
            this.rating.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rating.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.rating.Location = new System.Drawing.Point(175, 62);
            this.rating.Name = "rating";
            this.rating.Size = new System.Drawing.Size(45, 17);
            this.rating.TabIndex = 4;
            this.rating.Text = "rating";
            this.rating.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.rating.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label1.Location = new System.Drawing.Point(92, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Directed by";
            this.label1.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.label1.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label2.Location = new System.Drawing.Point(92, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Language";
            this.label2.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.label2.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(251)))), ((int)(((byte)(248)))));
            this.label3.Location = new System.Drawing.Point(92, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Rating";
            this.label3.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.label3.MouseLeave += new System.EventHandler(this.Mouse_leave);
            // 
            // search_result_box
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(158)))), ((int)(((byte)(145)))));
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rating);
            this.Controls.Add(this.language);
            this.Controls.Add(this.director_name);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.pictureBox1);
            this.Name = "search_result_box";
            this.Size = new System.Drawing.Size(341, 91);
            this.Load += new System.EventHandler(this.search_result_box_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Mouse_click);
            this.MouseEnter += new System.EventHandler(this.Mouse_endter);
            this.MouseLeave += new System.EventHandler(this.Mouse_leave);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Label Title;
        public System.Windows.Forms.Label director_name;
        public System.Windows.Forms.Label language;
        public System.Windows.Forms.Label rating;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label3;
    }
}
