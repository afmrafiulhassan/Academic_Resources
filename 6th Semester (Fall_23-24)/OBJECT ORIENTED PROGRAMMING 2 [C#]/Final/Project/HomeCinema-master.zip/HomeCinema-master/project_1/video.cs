﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace project_1
{
    public class video
    {
        private const string connectionString = "Server=localhost;Database=the_media_library;User ID=root;Password=toor;";
       

        public static List<video> videoList = new List<video>();  

    }
}
