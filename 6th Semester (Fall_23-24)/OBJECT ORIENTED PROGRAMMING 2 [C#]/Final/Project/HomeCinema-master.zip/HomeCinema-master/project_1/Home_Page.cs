﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Xml.Linq;

namespace project_1
{
    public partial class Home_Page : Form
    {
        public Form1 login_page;
        public Form3 upload_page;
        public user usr;
        private MySqlConnection connection;
        private Timer timer;
        private int currentImageIndex = 0;
        private const string connectionString = "Server=localhost;Database=the_media_library;User ID=root;Password=toor;";
        private string[] backgroundImagePaths = {
        @"C:\Users\pc\Documents\pic1.jpg",
        @"C:\Users\pc\Documents\pic2.jpg",
        @"C:\Users\pc\Documents\pic3.jpg",
        @"C:\Users\pc\Documents\Untitled design (1).png",
        "C:\\Users\\pc\\Documents\\Untitled design.png",
       // "C:\\Users\\pc\\Documents\\"
        // Add more image paths as needed
    };
        public Home_Page()
        {
           //login_page = new Form1();
            InitializeComponent();
            si_fi_flowLayoutPane.FlowDirection = FlowDirection.LeftToRight;
            si_fi_flowLayoutPane.WrapContents = false;
            textBox1.Leave += textBox1_Leave;

        }
        public Home_Page(Form1 f)
        {

            this.login_page = f;
            InitializeTimer();
            InitializeComponent();
            si_fi_flowLayoutPane.FlowDirection = FlowDirection.RightToLeft;
            textBox1.Leave += textBox1_Leave;

        }
        public Home_Page(Form1 f , user u)
        {

            this.usr = u;
            this.login_page = f;
            InitializeComponent();
            InitializeTimer();
            // Action_flowLayoutPane.FlowDirection = FlowDirection.RightToLeft;
            si_fi_flowLayoutPane.FlowDirection = FlowDirection.LeftToRight;
            si_fi_flowLayoutPane.WrapContents = false;
            textBox1.Leave += textBox1_Leave;
            if (this.usr.is_admin==true) {
                this.upload_picture.Show();
            }
            else
            {
                this.upload_picture.Hide();    
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.Close();
            //f1.Close();
        }

        private void Log_out_btn_Click(object sender, EventArgs e)
        {

         //   this.login_page.Show();
            //this.Hide();
            //iteams();
            

        }
        public void home_page_load(object sender,EventArgs e)
        {
            try
            {
                connection = new MySqlConnection(connectionString);
                connection.Open();
                // MessageBox.Show("Ok");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error connecting to the database: {ex.Message}");
            }
            si_fi_iteams();
            action_iteams();
            anime_iteams();
            comedy_iteams();
            recent_iteams();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            timer = new Timer();
            timer.Interval = 3000; // 3 seconds
            timer.Tick += Timer_Tick;
            timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            panel9.BackgroundImage = Image.FromFile(backgroundImagePaths[currentImageIndex%backgroundImagePaths.Length]);
            currentImageIndex++;
            // Change the background image of the panel
           /* if (currentImageIndex < backgroundImagePaths.Length)
            {
                panel9.BackgroundImage = Image.FromFile(backgroundImagePaths[currentImageIndex]);
                currentImageIndex++;
            }
            else
            {
                // Reset to the first image when all images have been cycled
                currentImageIndex = 0;
                panel9.BackgroundImage = Image.FromFile(backgroundImagePaths[currentImageIndex]);
            }*/
        }
        public void si_fi_iteams()
        {
            action_flowLayoutPanel.Controls.Clear();
            Media_Box[] media_Boxes = new Media_Box[20];
            string query = "SELECT * FROM video WHERE CategoryID = 1";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    int index = 0;
                    while (reader.Read() && index < media_Boxes.Length)
                    {
                        // Initialize Media_Box objects with data from the database
                        media_Boxes[index] = new Media_Box();
                        media_Boxes[index].title = Path.GetFileNameWithoutExtension(reader["title"].ToString());
                        media_Boxes[index].poster_path = reader["video_poster_link"].ToString();
                        media_Boxes[index].video_utl = reader["videolink"].ToString() ;
                       // media_Boxes[index].label2.Text = reader["director_name"].ToString();
                        media_Boxes[index].DirectorName = reader["director_name"].ToString();
                        media_Boxes[index].Rating = reader["ratings"].ToString();
                        media_Boxes[index].MainActorName = reader["actor_name"].ToString();
                        media_Boxes[index].Language = reader["Language"].ToString();


                        string s = media_Boxes[index].poster_path;
                        Image img = Image.FromFile(@s);
                        media_Boxes[index].poster.Image = img;

                        // Add Media_Box to the FlowLayoutPanel
                        action_flowLayoutPanel.Controls.Add(media_Boxes[index]);

                        index++;
                    }
                }
            }

            /*
            Media_Box[] media_Boxes = new Media_Box[20];
            for(int i =0;i<media_Boxes.Length;i++)
            {
                media_Boxes[i] = new Media_Box();
                media_Boxes[i].title = "video " +Convert.ToString(i);
                media_Boxes[i].poster_path = @"C:\Users\pc\Desktop\server\Poster\bg_image.jpg";
                
                Action_flowLayoutPane.Controls.Add(media_Boxes[i]);
            }*/
        }
        public void action_iteams()
        {
            si_fi_flowLayoutPane.Controls.Clear();  
            Media_Box[] media_Boxes = new Media_Box[20];
            string query = "SELECT * FROM video WHERE CategoryID = 6";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    int index = 0;
                    while (reader.Read() && index < media_Boxes.Length)
                    {
                        // Initialize Media_Box objects with data from the database
                        media_Boxes[index] = new Media_Box();
                        media_Boxes[index].title = Path.GetFileNameWithoutExtension(reader["title"].ToString());
                        media_Boxes[index].poster_path = reader["video_poster_link"].ToString();
                        media_Boxes[index].video_utl = reader["videolink"].ToString();
                        media_Boxes[index].DirectorName = reader["director_name"].ToString();
                        media_Boxes[index].Rating = reader["ratings"].ToString();
                        media_Boxes[index].MainActorName = reader["actor_name"].ToString();
                        media_Boxes[index].Language = reader["Language"].ToString();
                        string s = media_Boxes[index].poster_path;
                        Image img = Image.FromFile(@s);
                        media_Boxes[index].poster.Image = img;

                        // Add Media_Box to the FlowLayoutPanel
                        si_fi_flowLayoutPane.Controls.Add(media_Boxes[index]);

                        index++;
                    }
                }
            }
        }
        private void anime_iteams()
        {
            anime_flowLayoutPanel.Controls.Clear();
            Media_Box[] media_Boxes = new Media_Box[20];
            string query = "SELECT * FROM video WHERE CategoryID = 5";


            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    int index = 0;
                    while (reader.Read() && index < media_Boxes.Length)
                    {
                        // Initialize Media_Box objects with data from the database
                        media_Boxes[index] = new Media_Box();
                        media_Boxes[index].title = Path.GetFileNameWithoutExtension(reader["title"].ToString());
                        media_Boxes[index].poster_path = reader["video_poster_link"].ToString();
                        media_Boxes[index].video_utl = reader["videolink"].ToString();
                        string s = media_Boxes[index].poster_path;
                        media_Boxes[index].DirectorName = reader["director_name"].ToString();
                        media_Boxes[index].Rating = reader["ratings"].ToString();
                        media_Boxes[index].MainActorName = reader["actor_name"].ToString();
                        media_Boxes[index].Language = reader["Language"].ToString();
                        Image img = Image.FromFile(@s);
                        media_Boxes[index].poster.Image = img;

                        // Add Media_Box to the FlowLayoutPanel
                        anime_flowLayoutPanel.Controls.Add(media_Boxes[index]);

                        index++;
                    }
                }
            }
        }
        private void comedy_iteams()
        {
            comedy_flowLayoutPanel4.Controls.Clear();
            Media_Box[] media_Boxes = new Media_Box[20];
            string query = "SELECT * FROM video WHERE CategoryID = 2";


            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    int index = 0;
                    while (reader.Read() && index < media_Boxes.Length)
                    {
                        // Initialize Media_Box objects with data from the database
                        media_Boxes[index] = new Media_Box();
                        media_Boxes[index].title = Path.GetFileNameWithoutExtension(reader["title"].ToString());
                        media_Boxes[index].poster_path = reader["video_poster_link"].ToString();
                        media_Boxes[index].video_utl = reader["videolink"].ToString();
                        media_Boxes[index].DirectorName = reader["director_name"].ToString();
                        media_Boxes[index].Rating = reader["ratings"].ToString();
                        media_Boxes[index].MainActorName = reader["actor_name"].ToString();
                        media_Boxes[index].Language = reader["Language"].ToString();
                        string s = media_Boxes[index].poster_path;

                        Image img = Image.FromFile(@s);
                        media_Boxes[index].poster.Image = img;

                        // Add Media_Box to the FlowLayoutPanel
                        comedy_flowLayoutPanel4.Controls.Add(media_Boxes[index]);

                        index++;
                    }
                }
            }
        }
        private void recent_iteams()
        {
            recently_added_flowLayoutPanel.Controls.Clear();
            Media_Box[] media_Boxes = new Media_Box[20];
           // string query = "SELECT * FROM video WHERE CategoryID = 2";
            string query = "SELECT * FROM video ORDER BY VideoID DESC LIMIT 10";


            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    int index = 0;
                    while (reader.Read() && index < media_Boxes.Length)
                    {
                        // Initialize Media_Box objects with data from the database
                        media_Boxes[index] = new Media_Box();
                        media_Boxes[index].title = Path.GetFileNameWithoutExtension(reader["title"].ToString());
                        media_Boxes[index].poster_path = reader["video_poster_link"].ToString();
                        media_Boxes[index].video_utl = reader["videolink"].ToString();
                        media_Boxes[index].DirectorName = reader["director_name"].ToString();
                        media_Boxes[index].Rating = reader["ratings"].ToString();
                        media_Boxes[index].MainActorName = reader["actor_name"].ToString();
                        media_Boxes[index].Language = reader["Language"].ToString();
                        string s = media_Boxes[index].poster_path;

                        Image img = Image.FromFile(@s);
                        media_Boxes[index].poster.Image = img;

                        // Add Media_Box to the FlowLayoutPanel
                        recently_added_flowLayoutPanel.Controls.Add(media_Boxes[index]);

                        index++;
                    }
                }
            }
        }
        public void search_res_iteams(string searchTerm)
        {
           search_res_flowLayoutPanel.Controls.Clear();
            search_result_box[] search_res_box = new search_result_box[20];

            // Modify the query to include a search based on the title
            string query = "SELECT title,videolink, video_poster_link,director_name,ratings,Language FROM video WHERE title LIKE @SearchTerm";


            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                // Add a parameter to the query for the search term
                command.Parameters.AddWithValue("@SearchTerm", $"%{searchTerm}%");

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    int index = 0;
                    while(reader.Read() && index < search_res_box.Length)
                    {
                        // Initialize Media_Box objects with data from the database
                        search_res_box[index] = new search_result_box();
                        search_res_box[index].Title.Text = Path.GetFileNameWithoutExtension(reader["title"].ToString());
                        search_res_box[index].poster_path = reader["video_poster_link"].ToString();
                        search_res_box[index].VideoPath = reader["videolink"].ToString();
                        search_res_box[index].director_name.Text = reader["director_name"].ToString();
                        search_res_box[index].language.Text= reader["Language"].ToString();
                        search_res_box[index].rating.Text = reader["ratings"].ToString();
                        string s = search_res_box[index].poster_path;
                        Image img = Image.FromFile(@s);
                        search_res_box[index].pictureBox1.BackgroundImage = img;
                        search_res_flowLayoutPanel.Height = search_res_flowLayoutPanel.Controls.Count * 88;

                        // Add Media_Box to the FlowLayoutPanel
                        search_res_flowLayoutPanel.Controls.Add(search_res_box[index]);
                       // panel8.Controls.Add(search_res_box[index]);

                        index++;
                    }
                }
            }
        }
        private void textBox1_Leave(object sender, EventArgs e)
        {
            // Clear the search results when the text box loses focus
            this.search_res_flowLayoutPanel.Controls.Clear();
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            try 
            {
                user_info_form user_info = new user_info_form(this, this.login_page, this.usr);
                user_info.ShowDialog();
                //MessageBox.Show(this.usr.name);
            }catch(Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }

        private void upload_picture_Click(object sender, EventArgs e)
        {
           
            upload_page = new Form3(this);
            upload_page.Show();
            upload_page.FormClosed += (s, args) => this.Close();
            this.Hide();

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
        public void load_all_item()
        { 
            this.action_iteams();
            this.si_fi_iteams();
            this.comedy_iteams();
            this.recent_iteams();
            this.anime_iteams();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = textBox1.Text.Trim();

            // Only perform a search if the search term is not empty
            if (!string.IsNullOrEmpty(searchTerm))
            {
                search_res_iteams(searchTerm);
            }
            else
            {
                // If the search term is empty, clear the search results
                search_res_flowLayoutPanel.Height = 0;
                search_res_flowLayoutPanel.Controls.Clear();

            }
        }
    }
}
