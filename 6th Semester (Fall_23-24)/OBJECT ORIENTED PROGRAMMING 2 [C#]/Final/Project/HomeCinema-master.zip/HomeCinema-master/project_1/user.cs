﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    public class user
    {
        public string name;
        public string password;
        public string email;
        public string date_of_birth;
        public string gender;
        public bool is_admin = false;
    }
}
