﻿namespace project_1
{
    partial class user_info_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(user_info_form));
            this.user_info_log_out = new System.Windows.Forms.Button();
            this.user_info_user_name = new System.Windows.Forms.Label();
            this.user_info_user_email = new System.Windows.Forms.Label();
            this.user_info_date_of_birth = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.user_info_user_gender = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // user_info_log_out
            // 
            this.user_info_log_out.BackColor = System.Drawing.Color.Red;
            this.user_info_log_out.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.user_info_log_out.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_info_log_out.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_info_log_out.ForeColor = System.Drawing.Color.White;
            this.user_info_log_out.Location = new System.Drawing.Point(190, 357);
            this.user_info_log_out.Name = "user_info_log_out";
            this.user_info_log_out.Size = new System.Drawing.Size(84, 32);
            this.user_info_log_out.TabIndex = 0;
            this.user_info_log_out.Text = "Log Out";
            this.user_info_log_out.UseVisualStyleBackColor = false;
            this.user_info_log_out.Click += new System.EventHandler(this.user_info_log_out_Click);
            // 
            // user_info_user_name
            // 
            this.user_info_user_name.AutoSize = true;
            this.user_info_user_name.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_info_user_name.Location = new System.Drawing.Point(127, 28);
            this.user_info_user_name.Name = "user_info_user_name";
            this.user_info_user_name.Size = new System.Drawing.Size(56, 21);
            this.user_info_user_name.TabIndex = 0;
            this.user_info_user_name.Text = "Name";
            // 
            // user_info_user_email
            // 
            this.user_info_user_email.AutoSize = true;
            this.user_info_user_email.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_info_user_email.Location = new System.Drawing.Point(127, 69);
            this.user_info_user_email.Name = "user_info_user_email";
            this.user_info_user_email.Size = new System.Drawing.Size(53, 21);
            this.user_info_user_email.TabIndex = 2;
            this.user_info_user_email.Text = "Email";
            // 
            // user_info_date_of_birth
            // 
            this.user_info_date_of_birth.AutoSize = true;
            this.user_info_date_of_birth.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_info_date_of_birth.Location = new System.Drawing.Point(144, 158);
            this.user_info_date_of_birth.Name = "user_info_date_of_birth";
            this.user_info_date_of_birth.Size = new System.Drawing.Size(107, 21);
            this.user_info_date_of_birth.TabIndex = 3;
            this.user_info_date_of_birth.Text = "Date of Birth";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(77)))), ((int)(((byte)(96)))), ((int)(((byte)(75)))));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.user_info_date_of_birth);
            this.panel4.Controls.Add(this.user_info_user_gender);
            this.panel4.Controls.Add(this.user_info_user_name);
            this.panel4.Controls.Add(this.user_info_user_email);
            this.panel4.ForeColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(82, 143);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(323, 197);
            this.panel4.TabIndex = 2;
            // 
            // user_info_user_gender
            // 
            this.user_info_user_gender.AutoSize = true;
            this.user_info_user_gender.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_info_user_gender.Location = new System.Drawing.Point(127, 108);
            this.user_info_user_gender.Name = "user_info_user_gender";
            this.user_info_user_gender.Size = new System.Drawing.Size(65, 21);
            this.user_info_user_gender.TabIndex = 0;
            this.user_info_user_gender.Text = "Gender";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 21);
            this.label2.TabIndex = 5;
            this.label2.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 21);
            this.label3.TabIndex = 6;
            this.label3.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 21);
            this.label4.TabIndex = 7;
            this.label4.Text = "Date of Birth";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(190, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(97, 90);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // user_info_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(33)))), ((int)(((byte)(30)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(483, 411);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.user_info_log_out);
            this.Name = "user_info_form";
            this.Opacity = 0.95D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Load += new System.EventHandler(this.user_info_load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button user_info_log_out;
        private System.Windows.Forms.Label user_info_user_name;
        private System.Windows.Forms.Label user_info_user_email;
        private System.Windows.Forms.Label user_info_date_of_birth;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label user_info_user_gender;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}